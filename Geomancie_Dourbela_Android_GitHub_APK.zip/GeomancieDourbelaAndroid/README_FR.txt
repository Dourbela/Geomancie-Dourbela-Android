GÉOMANCIE DOURBELA — PROJET ANDROID
====================================

Ce dossier contient un projet Android Studio qui enveloppe la version web V4 de Géomancie Dourbela dans une application Android (WebView). L'interface HTML est embarquée dans l'application : elle peut donc fonctionner hors connexion. Les préférences et données enregistrées par l'application web utilisent le stockage local du WebView.

OUVRIR LE PROJET
1. Décompresser ce ZIP sur un ordinateur.
2. Installer Android Studio (version récente) et un JDK 17.
3. Dans Android Studio, choisir « Open » puis sélectionner le dossier GéomancieDourbelaAndroid.
4. Accepter la synchronisation Gradle et installer Android SDK Platform 35 si Android Studio le demande.
5. Pour fabriquer l'APK : Build > Build Bundle(s) / APK(s) > Build APK(s).
6. L'APK de débogage sera normalement dans app/build/outputs/apk/debug/app-debug.apk.

INSTALLATION SUR LE TÉLÉPHONE
Transférer app-debug.apk sur le téléphone Android, ouvrir le fichier et autoriser l'installation depuis cette source si Android le demande.

INFORMATIONS
- Nom : Géomancie Dourbela
- Identifiant : com.dourbela.geomancie
- Version : 1.0
- Android minimum : 6.0 (API 23)
- Aucun accès Internet n'est demandé ; le contenu principal est embarqué localement.

IMPORTANT
Ce ZIP est le projet source Android Studio, pas encore un APK compilé. La compilation finale nécessite Android Studio et le SDK Android. Le projet conserve la page V4 fournie, ses données et ses fonctions web.

COMPILATION AUTOMATIQUE SUR GITHUB
1. Créer un dépôt GitHub et y téléverser le contenu de ce dossier.
2. Ouvrir l'onglet Actions du dépôt.
3. Sélectionner « Construire APK Android », puis « Run workflow » si le workflow ne démarre pas automatiquement.
4. À la fin, ouvrir l'exécution réussie et télécharger l'artefact « Geomancie-Dourbela-APK ».
5. Décompresser l'artefact : il contient app-debug.apk, à transférer sur le téléphone Android.
